import cv2
import numpy as np
import os
'''
# 基本步骤
- step1: 识别出照片A中的人脸F1
- step2: 使用F1对人脸数据集中的人脸进行匹配
- step3: 得到匹配度最高的那张图片
- step4: 在照片A中的人脸位置写出查询出的名字
'''

# step1
def find_img_face(file_name):
	face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
	img = cv2.imread(file_name)# 加载图像
	img = cv2.resize(img, (960, 1280))
	gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)# 转换为灰度图像
	faces = face_cascade.detectMultiScale(gray, 1.1, 1)# 人脸检测
	# for (x,y,w,h) in faces:
	# 	img = cv2.rectangle(img, (x,y), (x+w,y+h), (255,0,0), 2)# 绘制矩形框
	(x,y,w,h) = faces[0]
	face_img = img[y:y+h, x:x+w]
	return face_img, (x,y,w,h)

# step2-step3
def match_img_face(face_img, face_datas_path):
	# 最相似接近0
	methods = cv2.TM_SQDIFF_NORMED#[cv.TM_SQDIFF_NORMED, cv.TM_CCORR_NORMED, cv.TM_CCOEFF_NORMED]
	face_w, face_h = face_img.shape[:2]
	import sys
	match_face_value = sys.maxsize
	match_face_point = None
	match_face_img = None
	match_face_name = None
	for img_name in os.listdir(face_datas_path):
		head_img = cv2.imread(face_datas_path+'/'+img_name)
		head_img = cv2.resize(head_img, (960, 1280))
		result = cv2.matchTemplate(head_img, face_img, methods)
		min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
		if min_val < match_face_value:
			match_face_value = min_val
			match_face_point = min_loc
			match_face_img = head_img
			match_face_name = img_name[:-4]
	rect = (match_face_point[0]+face_w, match_face_point[1]+face_h)
	return match_face_img, match_face_point, match_face_name, rect
	
# step4
def draw_face_name(match_face_img, match_face_point, match_face_name, rect):
	cv2.rectangle(match_face_img, match_face_point, rect, (0,255,0))
	cv2.putText(match_face_img, match_face_name, (match_face_point[0], match_face_point[1]-10), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 255, 0), 2)
	cv2.imshow('match_face',match_face_img)
	cv2.waitKey(0)

# #
def main():
	print('start ...')
	face_img, rect = find_img_face('face_detection/qinzixuan1.jpg')
	match_face_img, match_face_point, match_face_name, rect = match_img_face(face_img, 'face_detection')
	draw_face_name(match_face_img, match_face_point, match_face_name, rect)

if __name__ == '__main__':
	main()