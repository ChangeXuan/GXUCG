'''
打开图像，显示不同通道
'''
import cv2
import numpy as np

def main(cannel, img_name):
	img = cv2.imread(img_name)
	rect_img = img.copy()
	# opencv的颜色通道排布为BGR
	for index in range(3):
		if index == cannel:
			continue
		rect_img[:,:,index] = 0
	cv2.imshow('src_img', img)
	cv2.imshow('rect_img', rect_img)
	cv2.waitKey(0)

if __name__ == '__main__':
	cannel = 2
	main(cannel, 'vim.png')