'''
合并图像
'''
import cv2
import numpy as np

def main(img_name1, img_name2):
	img1 = cv2.imread(img_name1)
	img2 = cv2.imread(img_name2)
	img1 = cv2.resize(img1, (200, 200))
	img2 = cv2.resize(img2, (200, 400))
	# black = np.zeros(img1.shape, np.uint8)
	
	all_shape = (img2.shape[0], img2.shape[0], 3)
	all_img = np.zeros(all_shape, np.uint8)
	#

	all_img[:img1.shape[0], :img1.shape[1]] = img1
	all_img[:, img1.shape[1]: ] = img2

	cv2.imshow('src_img', img1)
	cv2.imshow('rect_img', img2)
	cv2.imshow('a', all_img)
	cv2.waitKey(0)

if __name__ == '__main__':
	main('test.jpg', 'test.jpg')