'''
打开图像，保存矩形区域
'''
import cv2
import numpy as np

def main(self_rect, img_name):
	img = cv2.imread(img_name)
	rect_img = img[self_rect[1]:self_rect[3], self_rect[0]:self_rect[2]]
	cv2.imshow('src_img', img)
	cv2.imshow('rect_img', rect_img)
	cv2.waitKey(0)

if __name__ == '__main__':
	self_rect = [100,100,300,300]
	main(self_rect, 'test.jpg')