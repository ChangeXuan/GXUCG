'''
打开图像，竖直对称变换
'''
import cv2
import numpy as np

def main(img_name):
	img = cv2.imread(img_name)
	center_point = (img.shape[1]//2, img.shape[0]//2)
	temp_img = np.zeros(img.shape, np.uint8)
	temp_img[:center_point[1], :] = img[center_point[1]:, :]
	temp_img[center_point[1]:, :] = img[:center_point[1], :]

	cv2.imshow('src_img', temp_img)
	cv2.imshow('rect_img', img)
	cv2.waitKey(0)

if __name__ == '__main__':
	main('test.jpg')