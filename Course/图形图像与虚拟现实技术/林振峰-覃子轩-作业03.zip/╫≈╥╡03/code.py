import cv2
import numpy as np

def cal_axis(img):
	_, w = img.shape
	center_x = w//2
	return center_x

def cal_fifty(img, center_x):
	#(x, y)
	point_x_ary = []
	point_y_ary = []
	for dis_x in range(1, img.shape[1]-center_x):
		left_item = center_x-dis_x
		right_item = center_x+dis_x
		for dix_y in range(img.shape[0]):
			if img[dix_y][left_item] == 1 and img[dix_y][right_item] == 1:
				point_x_ary.append(left_item)
				point_y_ary.append(dix_y)

	min_x = min(point_x_ary)
	min_y = min(point_y_ary)
	max_x = img.shape[1]-min_x
	max_y = max(point_y_ary)
	box_rect = [(min_x, min_y), (max_x, max_y)]
	return img, box_rect

# 放大标识框，美观
def resize_box(box_rect, scale_szie=30):
	left_point = (box_rect[0][0]-scale_szie, box_rect[0][1]-scale_szie)
	right_point = (box_rect[1][0]+scale_szie, box_rect[1][1]+scale_szie)
	return [left_point, right_point]

def main(img_path):
	src_img = cv2.imread(img_path)
	gary_img = cv2.cvtColor(src_img, cv2.COLOR_BGR2GRAY)

	dst = cv2.cornerHarris(gary_img, 2, 29, 0.04)
	dst[dst < 0.01 * dst.max()] = 0
	dst[dst > 0.01 * dst.max()] = 1
	kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(7, 7))
	
	dst = cv2.dilate(dst,kernel)
	center_x = cal_axis(dst)
	dst, box_rect = cal_fifty(dst, center_x)

	box_rect = resize_box(box_rect)

	cv2.rectangle(src_img, box_rect[0], box_rect[1], [0, 255 , 0])
	cv2.imshow('src_img', src_img)
	# cv2.imshow('temp_img', dst)
	cv2.waitKey(0)

if __name__ == '__main__':
	img_path = 'girl.jpg'
	main(img_path)