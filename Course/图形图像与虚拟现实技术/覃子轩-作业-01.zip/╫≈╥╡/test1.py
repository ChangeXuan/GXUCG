# 导入显示图像的组件
import matplotlib.pyplot as plt
# 导入skimage自带的数据信息
from skimage import data
# 导入skimage颜色变换的库
from skimage.color import rgb2hed
# 导入颜色对应
from matplotlib.colors import LinearSegmentedColormap

# 自定义colormap，把元组内的颜色值映射到0-1区间
cmap_hema = LinearSegmentedColormap.from_list('mycmap', ['white', 'red'])
cmap_dab = LinearSegmentedColormap.from_list('mycmap', ['white', 'saddlebrown'])
cmap_eosin = LinearSegmentedColormap.from_list('mycmap', ['darkviolet', 'white'])

# 从data中取出rgb颜色空间的图片
ihc_rgb = data.immunohistochemistry()
# 把图片从rgb颜色空间转为hed颜色空间空间
ihc_hed = rgb2hed(ihc_rgb)

# 设置plt的显示图片区域
fig, axes = plt.subplots(2, 2, figsize=(7, 6), sharex=True, sharey=True)
# 将axes转为以为数组
ax = axes.ravel()

# imshow为显示的图片
# set_title为设置图片上方的名字
ax[0].imshow(ihc_rgb)
ax[0].set_title("Original image")

# [:,:,:]为python中的切片操作
# 第三个参数为颜色通道
# camp为自定义的colormap
ax[1].imshow(ihc_hed[:, :, 0], cmap=cmap_hema)
ax[1].set_title("Hematoxylin")

ax[2].imshow(ihc_hed[:, :, 1], cmap=cmap_eosin)
ax[2].set_title("Eosin")

ax[3].imshow(ihc_hed[:, :, 2], cmap=cmap_dab)
ax[3].set_title("DAB")
for a in ax.ravel():
    # 关闭轴显示
    a.axis('off')
# 自动调整子图参数
fig.tight_layout()
# plt.show()


import numpy as np
from skimage.exposure import rescale_intensity

# 重新调整图片
# 切片对不同的通道进行操作
# 把hed图像的h通道和d通道的数据范围约束到0-1之间
h = rescale_intensity(ihc_hed[:, :, 0], out_range=(0, 1))
d = rescale_intensity(ihc_hed[:, :, 2], out_range=(0, 1))
# np.zeros_like(h)返回一个全为0的array，他的shape和h的shape一样
# np.dstack(a1,a2,a3)把a1,a2,a3按列插入，即
'''
	[a11,a21,a31]
	[a12,a22,a32]
	...
'''
zdh = np.dstack((np.zeros_like(h), d, h))
# 创建一个新的承载图片的ui
fig = plt.figure()
axis = plt.subplot(1, 1, 1, sharex=ax[0], sharey=ax[0])
# 把图片加载到axis
axis.imshow(zdh)
# 设置标题
axis.set_title("Stain separated image (rescaled)")
# 关闭轴
axis.axis('off')
# 显示全部加载进plt的图片
plt.show()