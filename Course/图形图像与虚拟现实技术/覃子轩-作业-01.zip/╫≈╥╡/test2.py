from skimage.color.adapt_rgb import adapt_rgb, each_channel, hsv_value
from skimage import filters


# 对图片的每个通道进行sobel计算
@adapt_rgb(each_channel)
def sobel_each(image):
	return filters.sobel(image)


# 把rgb空间转到hsv后计算sobel
@adapt_rgb(hsv_value)
def sobel_hsv(image):
	# 使用soble变化求解image的边缘
	return filters.sobel(image)

from skimage import data
from skimage.exposure import rescale_intensity
import matplotlib.pyplot as plt

# 通过data来取得需要的图片
# 这里的image的shape为512*512*3
image = data.astronaut()

# 设置如何显示图片
fig, (ax_each, ax_hsv) = plt.subplots(ncols=2, figsize=(14, 7))

# We use 1 - sobel_each(image) but this won't work if image is not normalized
# 重新调整图片
ax_each.imshow(rescale_intensity(1 - sobel_each(image)))
ax_each.set_xticks([]), ax_each.set_yticks([])
ax_each.set_title("Sobel filter computed\n on individual RGB channels")

# We use 1 - sobel_hsv(image) but this won't work if image is not normalized
ax_hsv.imshow(rescale_intensity(1 - sobel_hsv(image)))
ax_hsv.set_xticks([]), ax_hsv.set_yticks([])
ax_hsv.set_title("Sobel filter computed\n on (V)alue converted image (HSV)")

# plt.show()

# 标准格式的自定义装饰器
def handler(image_filter, image, *args, **kwargs):
    image = image_filter(image, *args, **kwargs)
    return image

from skimage.color import rgb2gray

# 自定义的装饰器
# 这里的image_filter为filters.soble()
def as_gray(image_filter, image, *args, **kwargs):
    # 把iamge从rgb空间转到gray灰度空间
    gray_image = rgb2gray(image)
    # 使用image_filter对图片进行计算
    return image_filter(gray_image, *args, **kwargs)

@adapt_rgb(as_gray)
def sobel_gray(image):
    return filters.sobel(image)

fig, ax = plt.subplots(ncols=1, nrows=1, figsize=(7, 7))

# We use 1 - sobel_gray(image) but this won't work if image is not normalized
ax.imshow(rescale_intensity(1 - sobel_gray(image)), cmap=plt.cm.gray)
ax.set_xticks([]), ax.set_yticks([])
ax.set_title("Sobel filter computed\n on the converted grayscale image")

plt.show()

