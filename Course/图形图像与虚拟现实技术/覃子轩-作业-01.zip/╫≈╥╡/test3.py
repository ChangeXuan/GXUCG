# 导入一些需要使用到的库
import numpy as np
import matplotlib.pyplot as plt

from scipy.ndimage import gaussian_filter
from skimage import data
from skimage import img_as_float
from skimage.morphology import reconstruction

# data.coins()表示从data数据中取出硬币图片
# img_as_float把图片中的值转成float
# 之前直接读出来的图片为uint类型
image = img_as_float(data.coins())
# 使用高斯滤波器对图片进行滤波(平滑)
image = gaussian_filter(image, 1)
# 把image拷贝给seed
# 如果不适用copy进行深度拷贝，当修改seed时也会影响到image
# 因为他们共享内存
seed = np.copy(image)
# 切片范围为每一行(除了第一行和最后一行)的第二个数据到倒数第二个数据
# image.min()为取得image中的最小值
# 即除了边框，其他值都是image的最小值
seed[1:-1, 1:-1] = image.min()
# 把image复制个mask
mask = image

# reconstruction对图像进行形态学重建
# seed给出了传播的值
# mask给出了每个像素的最大允许值
dilated = reconstruction(seed, mask, method='dilation')
# 构建一个plt装载图片
fig, (ax0, ax1, ax2) = plt.subplots(nrows=1,
                                    ncols=3,
                                    figsize=(8, 2.5),
                                    sharex=True,
                                    sharey=True)

ax0.imshow(image, cmap='gray')
ax0.set_title('original image')
ax0.axis('off')

# vmin和vmax用来限制dilated的值
ax1.imshow(dilated, vmin=image.min(), vmax=image.max(), cmap='gray')
ax1.set_title('dilated')
ax1.axis('off')

# 图片做差
ax2.imshow(image - dilated, cmap='gray')
ax2.set_title('image - dilated')
ax2.axis('off')

fig.tight_layout()
# plt.show()

h = 0.4
seed = image - h
dilated = reconstruction(seed, mask, method='dilation')
hdome = image - dilated

fig, (ax0, ax1, ax2) = plt.subplots(nrows=1, ncols=3, figsize=(8, 2.5))
yslice = 197

# 显示某(197)一行的数据
ax0.plot(mask[yslice], '0.5', label='mask')
ax0.plot(seed[yslice], 'k', label='seed')
# ax0.plot(dilated[yslice], 'r', label='dilated')
ax0.set_ylim(-0.2, 2)
ax0.set_title('image slice')
ax0.set_xticks([])
ax0.legend()

ax1.imshow(dilated, vmin=image.min(), vmax=image.max(), cmap='gray')
# 绘制一条红色的线
ax1.axhline(yslice, color='r', alpha=0.4)
ax1.set_title('dilated')
ax1.axis('off')

ax2.imshow(hdome, cmap='gray')
ax2.axhline(yslice, color='r', alpha=0.4)
ax2.set_title('image - dilated')
ax2.axis('off')

fig.tight_layout()
plt.show()