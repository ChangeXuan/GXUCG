//
//  ShowStickyView.swift
//  SimpleSticky
//
//  Created by 覃子轩 on 2017/7/19.
//  Copyright © 2017年 覃子轩. All rights reserved.
//

import UIKit

protocol ShowStickyDelegate:NSObjectProtocol{
    func showStickyCall(_ content:String)
    func longPreeCall(_ content:String)
}

class ShowStickyView: UIView {
    
    var stickText:UITextView! = nil
    weak var delegate:ShowStickyDelegate!
    var saveStr:String = ""
    let colorAry:[UIColor] = [UIColor.init(red: 254/255, green: 244/255, blue: 139/255, alpha: 1),
                              UIColor.init(red: 155/255, green: 235/255, blue: 248/255, alpha: 1),
                              UIColor.init(red: 253/255, green: 185/255, blue: 187/255, alpha: 1),
                              UIColor.init(red: 166/255, green: 186/255, blue: 251/255, alpha: 1)]
    
    init(frame: CGRect,_ content:String,_ randomR:CGFloat) {
        super.init(frame: frame)
        
        self.initSelf()
        
        let tapeY = self.initBlackTape()
        self.initStickyText(tapeY,content)
  
        let randomR = self.randomRotation(randomR)
        
        self.saveStr = String.init(format: "%.2f|&%.2f|&%.1f|&\(content)",
                                         self.center.x,self.center.y,randomR)
        
    }
    
    /// 初始化自身
    ///
    /// - returns:
    private func initSelf() {
        self.backgroundColor = self.colorAry[Int(arc4random_uniform(UInt32(self.colorAry.count)))]
        // 阴影
        self.layer.shadowOffset = CGSize.init(width: 1, height: 1)
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowRadius = 3
        self.layer.shadowOpacity = 0.5
    }
    
    /// 初始化黑色胶带
    ///
    /// - returns:
    private func initBlackTape() -> CGFloat {
        let tapeView = UIView.init(frame: CGRect.init(x: 0, y: -15, width: 20, height: 25))
        tapeView.center.x = self.frame.width*0.5
        tapeView.backgroundColor = UIColor.black
        tapeView.alpha = 0.6
        self.addSubview(tapeView)
        
        return tapeView.frame.maxY
    }
    
    /// 初始化sticky内容
    ///
    /// - returns:
    private func initStickyText(_ startY:CGFloat,_ content:String) {
        self.stickText = UITextView.init(frame: CGRect.init(x: 0, y: startY, width: self.frame.width, height: self.frame.height-startY))
        self.stickText.backgroundColor = UIColor.clear
        self.stickText.isEditable = false
        self.stickText.isSelectable = false
        self.stickText.text = content
        
        //单击监听
        let tapSingle=UITapGestureRecognizer(target:self,action:#selector(tapStickOne))
        tapSingle.numberOfTapsRequired = 1
        tapSingle.numberOfTouchesRequired = 1
        self.stickText.addGestureRecognizer(tapSingle)
        
        //长按监听
        let longPress = UILongPressGestureRecognizer(target:self,action:#selector(longPress(_:)))
        self.stickText.addGestureRecognizer(longPress)
        
        self.addSubview(self.stickText)
    }
    
    /// 初始化随机旋转
    private func randomRotation(_ randomR:CGFloat) -> CGFloat {
        // -0.5~0.5
        var rotationA = CGFloat(-5+Int(arc4random_uniform(11)))*0.1
        if randomR != 1 {
            rotationA = randomR
        }
        self.transform = CGAffineTransform.init(rotationAngle: rotationA)
        return rotationA
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

// MARK: - 响应事件
extension ShowStickyView {
    
    @objc fileprivate func tapStickOne() {
        self.delegate.showStickyCall(self.stickText.text)
        
    }
    
    @objc fileprivate func longPress(_ sender: UILongPressGestureRecognizer){
        if sender.state == .began {
            self.removeFromSuperview()
            self.delegate.longPreeCall(self.saveStr)
        }
    }
    
}

