//
//  DeviceInfo.swift
//  SimpleSticky
//
//  Created by 覃子轩 on 2017/7/19.
//  Copyright © 2017年 覃子轩. All rights reserved.
//

import UIKit

//屏幕的宽
let DEVICEWIDTH = UIScreen.main.bounds.size.width
//屏幕的高
let DEVICEHEIGH = UIScreen.main.bounds.size.height

/*  判断是不是第一次打开应用
 *
 *  zeroSwift 16-10-2
 */
func isFirstStart() -> Bool{
    //得到当前的版本号
    let infoDictiomary = Bundle.main.infoDictionary
    let currentAppVersion = infoDictiomary!["CFBundleShortVersionString"] as! String
    
    //取出之前保存的版本号
    let userDefaults = UserDefaults.standard
    let appVersion = userDefaults.string(forKey: "appVersion")
    
    //appVersion ＝＝ nil说明是第一次启动；appVersion!=currntAppVersion说明是不等于当前的版本号，有更新
    if appVersion == nil || appVersion != currentAppVersion {
        userDefaults.setValue(currentAppVersion, forKey: "appVersion")
        return true
    }
    return false
}
