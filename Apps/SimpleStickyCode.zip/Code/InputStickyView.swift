//
//  InputStickyView.swift
//  SimpleSticky
//
//  Created by 覃子轩 on 2017/7/19.
//  Copyright © 2017年 覃子轩. All rights reserved.
//

import UIKit

class InputStickyView: UIView {
    
    var inputStickyText:UITextView! = nil
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        //self.backgroundColor = UIColor.clear
        //self.image = UIImage.init(named: "inputImg")
        
        let blurEffect = UIBlurEffect(style: .light)
        let blurView = UIVisualEffectView(effect: blurEffect)
        blurView.frame.size = CGSize(width: self.frame.width, height: self.frame.height)
        let vibrancyView = UIVisualEffectView(effect:UIVibrancyEffect.init(blurEffect: blurEffect))
        vibrancyView.frame.size = CGSize(width: self.frame.width, height: self.frame.height)
        blurView.contentView.addSubview(vibrancyView)
        self.addSubview(blurView)
        
        
        inputStickyText = UITextView.init(frame: CGRect.init(x: 10, y: 20,width: self.frame.width-20, height: self.frame.height-20))
        inputStickyText.backgroundColor = UIColor.clear
        inputStickyText.font = UIFont.systemFont(ofSize: 15)
        inputStickyText.textColor = UIColor.black
        inputStickyText.autocorrectionType = .no
        self.addSubview(inputStickyText)
        //vibrancyView.contentView.addSubview(inputStickyText)
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        print("inputView")
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
