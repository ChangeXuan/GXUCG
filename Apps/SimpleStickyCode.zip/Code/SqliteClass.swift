//
//  SqliteClass.swift
//  AtWill
//
//  Created by 覃子轩 on 2017/4/22.
//  Copyright © 2017年 覃子轩. All rights reserved.
//

import UIKit

class SqliteClass: NSObject {
    
    var db:SQLiteDB!
    
    override init() {
        //获取数据库实例
        db = SQLiteDB.shared
        
    }
    
    /// 创建表
    ///
    /// - returns:
    public func initTable() {
        //如果表还不存在则创建表（其中uid为自增主键）
        let _ = db.execute(sql: "create table if not exists t_user(uid integer primary key,content text)")
    }
    
    //从SQLite加载数据
    public func getData() -> [String] {
        let data = db.query(sql: "select * from t_user")
        var contentAry:[String] = []
        for item in data {
            contentAry.append(item["content"] as! String)
        }
        return contentAry
    }
    
    //保存数据到SQLite
    public func saveData(_ content:String) {
        //插入数据库，这里用到了esc字符编码函数，其实是调用bridge.m实现的
        let sql = "insert into t_user(content) values('\(content)')"
        //通过封装的方法执行sql
        let result = db.execute(sql: sql)
        print(result)
    }
    
    
    /// 删除表
    public func deleteContent(_ content:String) {
        //let _ = db.execute(sql: "DROP TABLE t_user")
        let _ = db.execute(sql: "DELETE FROM t_user WHERE content = \"\(content)\"")
    }
    
}
