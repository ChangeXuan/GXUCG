//
//  AddStickyButton.swift
//  SimpleSticky
//
//  Created by 覃子轩 on 2017/7/19.
//  Copyright © 2017年 覃子轩. All rights reserved.
//

import UIKit

protocol AddStickyDelegate:NSObjectProtocol{
    func addStickyCall()
}

class AddStickyButton: UIButton {
    
    weak var delegate:AddStickyDelegate?
    
    init(frame: CGRect,_ imgName:String = "addSticky") {
        super.init(frame: frame)
        
        self.setImage(UIImage.init(named: imgName), for: .normal)
        self.addTarget(self, action: #selector(self.addStickyAction(_:)), for: .touchUpInside)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

// MARK: - 响应事件
extension AddStickyButton {
    
    @objc fileprivate func addStickyAction(_ button:UIButton) {
        delegate?.addStickyCall()
    }
    
}
