//
//  ViewController.swift
//  SimpleSticky
//
//  Created by 覃子轩 on 2017/7/19.
//  Copyright © 2017年 覃子轩. All rights reserved.
//

import UIKit
import AudioToolbox

class ViewController: UIViewController {

    var addStickyButton:AddStickyButton! = nil
    var inputStickyView:InputStickyView! = nil
    let inputSize:CGFloat = 100
    var isAddSticky:Bool = false
    @IBOutlet weak var tipLabel: UILabel!
    
    // 数据库操作类
    var dbTool:SqliteClass!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.initAddButton()
        self.initInputSticky()
        self.initTipLabel()
        self.initDB()
        self.initShowSticky()
    }

    /// 自带的ViewController单击事件
    ///
    /// - parameter touches:
    /// - parameter event:
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let contentText = self.inputStickyView.inputStickyText.text
        
        //如果点击了添加按钮
        if self.isAddSticky {
            // 如果输入框在不在界面上
            if self.inputStickyView.center.y < 0 {
                if contentText != "" {
                    let point = touches.first!.location(in: self.view)
                    self.addShowSticky(point,contentText!)
                }
                
            } else {
                self.animateUp()
                self.addStickyButton.isEnabled = true
            }
        } else if self.inputStickyView.center.y > 0 {
            self.addStickyButton.isEnabled = true
            self.inputStickyView.inputStickyText.isEditable = true
            self.animateUp(false)
        }
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}

// MARK: - 拓展描述UI
extension ViewController {
    
    /// 初始化提示label
    ///
    /// - returns:
    fileprivate func initTipLabel() {
        self.tipLabel.alpha = 0
    }
    
    /// 初始化内容输入框
    ///
    /// - returns:
    fileprivate func initInputSticky() {
        self.inputStickyView = InputStickyView.init(frame: CGRect.init(x: 0, y: -inputSize, width: DEVICEWIDTH*0.5, height:inputSize))
        self.inputStickyView.center.x = self.view.center.x
        self.view.addSubview(self.inputStickyView)
    }
    
    /// 初始化添加便签的按钮
    ///
    /// - returns:
    fileprivate func initAddButton(_ size:CGFloat = 30) {
        self.addStickyButton = AddStickyButton.init(frame: CGRect.init(x: 0 , y: 0,
                                                                       width: size, height: size))
        self.addStickyButton.center = CGPoint.init(x: DEVICEWIDTH*0.5, y: DEVICEHEIGH-size)
        self.addStickyButton.delegate = self
        self.view.addSubview(addStickyButton)
        
    }
    
    /// 从数据库中加载标签
    ///
    /// - returns:
    fileprivate func initShowSticky() {
        let contentAry = dbTool.getData()
        for item in contentAry {
            let miniAry = item.components(separatedBy: "|&")
            if miniAry.count > 1 {
                let point = CGPoint.init(x: strToF(str: miniAry[0]), y:  strToF(str: miniAry[1]))
                let randomR = strToF(str: miniAry[2])
                let content = miniAry[3]
                self.addShowSticky(point, content, randomR ,true)
            }
            
        }
    }
    
    /// 添加便签
    ///
    /// - parameter point:
    /// - parameter content:
    fileprivate func addShowSticky(_ point:CGPoint,_ content:String,_ randomR:CGFloat = 1,_ isDB:Bool = false) {
        let w:CGFloat = 100
        let h:CGFloat = 120
        let stickyView = ShowStickyView.init(frame: CGRect.init(x: point.x-w*0.5, y: point.y-h*0.5,width: w, height: h),content,randomR)
        stickyView.delegate = self
        self.view.addSubview(stickyView)
        self.view.bringSubview(toFront: self.addStickyButton)
        self.isAddSticky = false
        self.animateLabel(0)
        
        if !isDB {
            dbTool.saveData(stickyView.saveStr)
        }
        
    }
    
}

// MARK: - 拓展描述方法
extension ViewController {
    
    /// 初始化数据库
    ///
    /// - returns:
    fileprivate func initDB() {
        dbTool = SqliteClass()
        dbTool.initTable()
    }
    
    
    /// 展现填写框
    fileprivate func showInputStickyView(_ flag:Bool = true) {
        self.isAddSticky = flag
        self.inputStickyView.inputStickyText.text = ""
        self.view.bringSubview(toFront: self.inputStickyView)
        self.animateDown(flag)
    }
    
    /// 填写框收回动画
    fileprivate func animateUp(_ flag:Bool = true) {
        
        UIView.animate(withDuration: 0.6, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.3, options: .curveEaseInOut, animations: {
            self.inputStickyView.center.y -= self.inputSize
        }) { (finish) in
            if flag {
                if self.inputStickyView.inputStickyText.text != "" {
                    self.animateLabel(1)
                }
                self.inputStickyView.inputStickyText.resignFirstResponder()
            }
        }
    }
    
    /// 填写框出现动画
    fileprivate func animateDown(_ flag:Bool) {
        
        UIView.animate(withDuration: 0.6, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.8, options: .curveEaseInOut, animations: { 
            self.inputStickyView.center.y += self.inputSize
            }) { (finish) in
                if flag {
                    self.inputStickyView.inputStickyText.becomeFirstResponder()
                }
        }
       
    }
    
    /// 提示label出现隐藏动画
    ///
    /// - parameter a:
    fileprivate func animateLabel(_ a:CGFloat) {
        UIView.animate(withDuration: 0.2, animations: {
            self.tipLabel.alpha = a
        })
    }
    
    /// String转CGFloat
    ///
    /// - parameter str:
    ///
    /// - returns:
    fileprivate func strToF(str:String) -> CGFloat{
        
        let string = str
        var cgFloat:CGFloat = 0
        
        if let doubleValue = Double(string) {
            cgFloat = CGFloat(doubleValue)
        }
        return cgFloat
    }
    
}

// MARK: - 拓展描述协议
extension ViewController: AddStickyDelegate,ShowStickyDelegate {
    
    /// 长按回调响应
    internal func longPreeCall(_ content: String) {
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate)
        dbTool.deleteContent(content)
    }
    
    /// 单击标签的回调响应
    ///
    /// - parameter content:
    internal func showStickyCall(_ content: String) {
        self.isAddSticky = false
        self.addStickyButton.isEnabled = false
        self.inputStickyView.inputStickyText.isEditable = false
        self.inputStickyView.inputStickyText.text = content
        self.view.bringSubview(toFront: self.inputStickyView)
        if self.inputStickyView.center.y < 0  {
            self.animateDown(false)
        }
        
    }
    
    /// 添加便签按钮的回调响应
    internal func addStickyCall() {
        self.showInputStickyView()
        self.addStickyButton.isEnabled = false
    }
}


